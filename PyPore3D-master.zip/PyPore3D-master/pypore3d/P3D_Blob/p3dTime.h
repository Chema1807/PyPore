void p3dResetStartTime ();
double p3dGetElapsedTime();
int p3dGetElapsedTime_min();
double p3dGetElapsedTime_sec();
